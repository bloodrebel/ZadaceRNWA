<?php
    return [
        "serverName" => "localhost",
        "userName" => "root",
        "password" => "root1234",
        "dbName" => "hr_dept"
    ];