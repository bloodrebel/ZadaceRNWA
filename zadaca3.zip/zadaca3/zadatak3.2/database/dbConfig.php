<?php
    return [
        "serverName" => "localhost",
        "userName" => "root",
        "password" => "",
        "dbName" => "hr_dept"
    ];