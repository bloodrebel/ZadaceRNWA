$(document).ready(function(){
    $("td").click(function(){
     alert($(this).text());
  });
});