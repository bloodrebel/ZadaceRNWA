<?php
    return [
        "serverName" => "localhost",
        "userName" => "root",
        "password" => "",
        "dbName" => "companies"
    ];